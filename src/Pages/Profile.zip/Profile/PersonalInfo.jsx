import React from "react";

function PersonalInfo() {
  return <div>PersonalInfo</div>;
}

export default PersonalInfo;
