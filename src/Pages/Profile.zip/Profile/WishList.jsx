import React from 'react'

function WishList() {
  return (
    <div>WishList</div>
  )
}

export default WishList