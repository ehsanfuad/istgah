import { Box } from "@mui/material";
import React from "react";

function AddressForm() {
  return <Box width="100vw" height="70vh" bgcolor="cadetblue"></Box>;
}

export default AddressForm;
